﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NewAss2
{

    public class Game
    {

        
        protected Level currentLevel;
        protected string _levelName = "No levels loaded";
        protected int _levelHeight = 0;
        protected int _levelWidth = 0;
        protected int _levelCount = 0; 
        List<Level> allLevels = new List<Level>(); // all level list
        List<string> levelNameList = new List<string>(); //all level name list


        //public Square[,] NewSquare;



        // Add addlevel method
        public void AddLevel(string name, int width, int height, string data)
        {
            Level newLevel = new Level(name, width, height, data);
            allLevels.Add(newLevel);
            _levelHeight = height;
            _levelWidth = width;
            _levelCount += 1;
            levelNameList.Add(name);
            _levelName = name;
            
        }

        public Level FindLevel(string targetLevel)
        {
            return allLevels.Find(Level => Level.GetName() == targetLevel);

        }


        public Square WhatIsAt(int x, int y) 
        {

            Level aLevel = FindLevel(_levelName);
            Square aSquare = aLevel.WhatIsAt(x ,y);
            return aSquare;
        }

        // create LevelNames list
        public List<string> LevelNames()
        {
            return levelNameList;

        }
        

        public void SetLevel(string newLevel)
        {
            string inPutLevel = newLevel;
            foreach (Level aLevel in allLevels)
            {
                if (aLevel.GetName() == inPutLevel)
                {
                    _levelName = inPutLevel;
                    _levelHeight = aLevel.CurrentLevelHeight;
                    _levelWidth = aLevel.CurrentLevelWidth;
                    currentLevel = aLevel;
                };
            }
                
            
        }

        public void SelectLevel(int index)
        {
            currentLevel = allLevels[index];
        }


        public int LevelCount
        {
            get => _levelCount;
        }
      
        public int LevelHeight
        {
            get => _levelHeight;
        }

        public int LevelWidth
        {
            get => _levelWidth;
        }

         

        //List<Level> allLevels = new List<Level>();


        public string CurrentLevelName
        {
            get => _levelName;
        }

        

        // making square










    }
}

