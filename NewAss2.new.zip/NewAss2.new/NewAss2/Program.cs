﻿using System;

namespace NewAss2
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();
            Console.WriteLine("** Empty game");
            Console.WriteLine($"Levels: {game.LevelCount}");
            Console.WriteLine($"CurrentLevel: {game.CurrentLevelName}.{ game.LevelWidth} x { game.LevelHeight}\n");

            string data = "0000 0001 0002 1011 1010 1110";
            game.AddLevel("*** simple game", 3, 1, data);
            Console.WriteLine($"CurrentLevel: {game.CurrentLevelName}.{ game.LevelWidth} x { game.LevelHeight}");
            Console.WriteLine(game);

            game.AddLevel("level 1", 3, 1, "0000 0001 0002 1011 1010 1110");
            game.AddLevel("level 2", 3, 1, "0000 0001 0002 1011 1010 1110");
            game.AddLevel("level 3", 3, 1, "0000 0001 0002 1011 1010 1110");

            Move(Directions.Down);

            SetSides(Sides.Top | Sides.Left);

            Console.ReadKey();


        }
        static void SetSides(Sides sides)
        {
            if (sides.HasFlag(Sides.Top)) { Console.WriteLine("Top"); }
            if (sides.HasFlag(Sides.Right)) { Console.WriteLine("Right"); }
            if (sides.HasFlag(Sides.Bottom)) { Console.WriteLine("Bottom"); }
            if (sides.HasFlag(Sides.Left)) { Console.WriteLine("Left"); }
            Console.WriteLine(sides);
        }
        static void Move(Directions direction)
        {
            Console.WriteLine(direction);
        }
    }
}
