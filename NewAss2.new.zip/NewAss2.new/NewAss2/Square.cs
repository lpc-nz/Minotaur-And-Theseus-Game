﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewAss2
{
    public class Square
    {
        public bool Top;
        public bool Right;
        public bool Bottom;
        public bool Left;

        public Square(bool top, bool right, bool bottom, bool left)
        {
            Top = top;
            Right = right;
            Bottom = bottom;
            Left = left;

        }

        public bool Minotaur { get;  }
    }
}
