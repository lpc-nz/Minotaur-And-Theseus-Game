﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewAss2
{
    public class Minotaur
    {
        public Minotaur(int x, int y)
        {
        }
    }
}
