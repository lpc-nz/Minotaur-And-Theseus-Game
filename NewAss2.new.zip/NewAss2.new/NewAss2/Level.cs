﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewAss2
{
    public class Level
    {
        // build propoty of Level Class
        protected string _name;
        protected int _width;
        protected int _height;
        protected string _data;
        public Square[,] allMySquares; // create Square variable
        protected int _col = 0;
        protected int _row = 0;


        //Method to create Level
        public Level(string name, int width, int height, string data)
        {
            _name = name;
            _width = width;
            _height = height;
            _data = data;
            allMySquares = new Square[height, width]; //store new Square in Level              
         
            bool top = false;
            bool right = false;
            bool bottom = false;
            bool left = false;
            //Square[,] aSquare = new Square[_row,_col];
            //making loop to create Theseus, Minotaur, Exit
            for (int i = 0; i < 15; i += 5) // take the first part of array
            {
                int theseus = int.Parse(_data.Substring(0, 4));
                int minotaur = int.Parse(_data.Substring(5, 4));
                int exit = int.Parse(_data.Substring(11, 4));
            }
            // making loop to create walls
            for (int i = 15; i < _data.Length; i += 5)
            {
                 top = _data.Substring(i, 1).Equals("1");
                 right = _data.Substring(i + 1, 1).Equals("1");
                 bottom = _data.Substring(i + 2, 1).Equals("1");
                 left = _data.Substring(i + 3, 1).Equals("1");
                Square aSquare = new Square(top, right, bottom, left);
                allMySquares[_row, _col] = aSquare;
                if (_col < _width - 1)
                {
                    _col++;
                }
                else if (_col == _width -1 && _row < _height -1) //col reach the limit and the row still less than hight
                {
                    _row++; //increase row
                    _col = 0; // start at position 0
                }
              
            }
            //Square temSquare = new Square(top, right, bottom, left);

        }

        public Square GetSquare(int x, int y)
        {
            return allMySquares[x, y];
        }

        public Square Minotaur(int x, int y)
        {
            return allMySquares[x, y];
        }
        public string CurrentLevelName 
        {
            get => _name;
        }

        public int CurrentLevelHeight
        {
            get => _height;
        }

        public int CurrentLevelWidth
        {
            get => _width;
        }

        //public string LevelNames { get; set; }
        public string GetName()
        {
            return CurrentLevelName;
        }
        // store the Square in Level
        public Square WhatIsAt(int x, int y)
        {
            return allMySquares[x, y];
        }
    }
       
}
