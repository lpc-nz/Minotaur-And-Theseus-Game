﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewAss2
{
    enum Directions
    {
        Up,
        Down,
        Right,
        Left
    }
}
