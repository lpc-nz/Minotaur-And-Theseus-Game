﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewAss2
{
    [Flags]
    enum Sides
    {
        Top = 1,
        Right = 2,
        Bottom = 3,
        Left = 4
    }
}
